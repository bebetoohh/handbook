# 联系我们
---

__Amaze UI 使用问题、意见建议请直接在评论中留言，或[提交 Issue](https://github.com/allmobilize/amazeui/issues)，__以方便他人解决类似问题。开发团队不提供电话、邮件支持。

    
__其他联系__

- 地址：北京市海淀区海淀大街27号亿景大厦3层西区 100080
- 招聘：jobs@yunshipei.com