# The Next
---

Amaze UI 1.0 仍在进行 Bug 修复和细节调整完善；2.x 的规划也已经开始，详情可以查看[开发路线图](https://github.com/allmobilize/amazeui/wiki/Roadmap)。

如果你认同我们的理念（面向现代浏览器开发），欢迎把你的想法和建议反馈给我们。

