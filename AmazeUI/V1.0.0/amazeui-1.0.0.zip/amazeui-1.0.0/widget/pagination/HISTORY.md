# Pagination 更新日志
---

## v3.0.0 (2014.08.17)

- `NEW` 删除 `options.select` 选项，根据主题判断要生产的 HTML 结构；
- `NEW` 合并三个类似的主题为 `select`；
- `NEW` 主题颜色调整，细节优化。

## 2013-12-26 调整格式

## 2013-12-19 增加options选项select

详情：选择“启用select模式”时，对应的主题是theme-2，theme-3；否则，对应的是theme-1。
