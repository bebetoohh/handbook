# map 更新日志
---

## ver 1.0.0

- `NEW` [#33](http://git.yunshipei.net/all/dev/issues/33) 新增 map 模块；