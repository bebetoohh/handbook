# 3 Columns
---

3 列网格。

## 数据接口

```javascript
{
    "id": "",
    "className": ""
}
```