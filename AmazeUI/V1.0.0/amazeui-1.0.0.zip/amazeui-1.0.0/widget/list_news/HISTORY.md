# list_news 更新日志
---

## ver 2.1.1 (2014.02.19)

- `IMPROVED` header 部分判断调整；


## ver 2.1.0
- `NEW` 新增API：`localName`、`icon`；
- `NEW` 传递与主题关联的参数；
- `NEW` 颜色调色板接口
