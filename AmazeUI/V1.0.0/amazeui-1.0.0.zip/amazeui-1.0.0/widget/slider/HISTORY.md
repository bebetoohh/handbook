# slider 更细日志
---

## ver 2.1.0
- `NEW` 新增API：`localName`、`icon`；
- `NEW` 传递与主题关联的参数；
- `NEW` 调色板 API；