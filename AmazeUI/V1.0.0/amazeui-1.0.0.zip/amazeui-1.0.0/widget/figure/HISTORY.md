# figure 更新日志
---

## ver 1.2.0 (2014.02.21)

- `NEW` Pinch Zoom

## ver 1.1.1 (2014.01.24)

- `FIXED` [#462](https://github.com/allmobilize/issues/issues/462) 修复模板拼写错误: `figcaptionPostion` → `figcaptionPosition`


## ver 1.1.0
- `NEW` 新增API：`localName`、`icon`；
- `NEW` 传递与主题关联的参数；
- `NEW` 调色板 API；

## ver 1.0.0

- `NEW` 新增 figure 模块；