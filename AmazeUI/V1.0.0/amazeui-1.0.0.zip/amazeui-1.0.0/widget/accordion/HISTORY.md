# Accordion 更新日志
---

## ver 1.2.0 (2014.08.17)

- `IMPROVED` 使用 `Collapse` 插件实现交互，移除原来单独写的代码；
- `IMPROVED` 主题细节调整。

## ver 1.1.0

- `NEW` 新增API：`localName`、`icon`；
- `NEW` 传递与主题关联的参数；
- `NEW` 调色板 API；


## ver 1.0.0

- `NEW` [#423](https://github.com/allmobilize/issues/issues/423) 新增 Accordion 模块；