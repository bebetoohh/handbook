# Gallery 更新日志
---

## v1.3.0 (2014.09.26)

- `IMPROVED` 使用 PureView 插件；
- `IMPROVED` 增加 `data-rel` 接口，用于设置大图；
- `IMPROVED` 微信浏览器里调用内置的图片查看器。

## v1.2.0 (2014.02.21)

- `New` Pinch Zoom

## v1.1.1 (2014.01.22)

- `IMPROVED` 所有图标使用 font icon；
- `IMPROVED` [#460](https://github.com/allmobilize/issues/issues/460) Gallery IE Mobile 10+ 支持；

## ver 1.1.0 (2013.01.06)

- `NEW` 调色板 API；