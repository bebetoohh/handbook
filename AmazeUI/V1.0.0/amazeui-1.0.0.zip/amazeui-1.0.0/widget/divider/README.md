# Divider 分隔线
---

分隔线组件。

## 使用方法

### 直接使用

- 拷贝演示中的代码，粘贴到 Amaze UI HTML 模板（[点此下载](/getting-started)） `<body>` 区域。

### 使用 Handlebars

本组件 Handlebars partial 名称为 `divider`，使用细节参照[折叠面板组件](/widgets/accordion)。

### 云适配 WebIDE

本组件无需采集数据。

## 数据结构

```javascript
{
  "id": "",

  "className": "",

  "theme": "default"
}
```